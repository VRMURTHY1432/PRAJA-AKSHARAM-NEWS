# Backend/API starter

The included mobile app and website are front-end MVPs. For production use, connect them to a secure backend.

Recommended production API:
- POST /api/auth/login
- GET /api/news
- POST /api/news
- PUT /api/news/:id
- DELETE /api/news/:id
- GET /api/categories
- POST /api/media
- GET /api/epaper
- POST /api/ads
- POST /api/reporters
- POST /api/notifications

Recommended production stack:
- Node.js + Express or Firebase
- PostgreSQL/MySQL
- Cloud storage for photos/videos
- Firebase Cloud Messaging for push notifications
- HTTPS and role-based authentication

Do not use the demo admin password in production.
