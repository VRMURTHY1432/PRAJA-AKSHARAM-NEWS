import 'package:flutter/material.dart';

void main() => runApp(const PrajaAksharamApp());

class PrajaAksharamApp extends StatelessWidget {
  const PrajaAksharamApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PRAJA AKSHARAM NEWS',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.red),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  final List<Map<String, String>> news = const [
    {'cat': 'జిల్లా వార్తలు', 'title': 'మన జిల్లా – మన గర్వం', 'text': 'స్థానిక అభివృద్ధి, ప్రజా సమస్యలు మరియు ముఖ్యమైన తాజా సమాచారం.'},
    {'cat': 'విద్య', 'title': 'విద్యార్థులకు ముఖ్యమైన సమాచారం', 'text': 'పాఠశాలలు, పరీక్షలు, స్కాలర్‌షిప్‌లు మరియు విద్యా వార్తలు.'},
    {'cat': 'గిరిజన వార్తలు', 'title': 'గిరిజన ప్రాంతాల తాజా వార్తలు', 'text': 'గ్రామీణ మరియు గిరిజన ప్రాంతాల ప్రజా సమస్యలు, కార్యక్రమాలు.'},
    {'cat': 'ఉద్యోగాలు', 'title': 'ప్రభుత్వ ఉద్యోగాల సమాచారం', 'text': 'అధికారిక నోటిఫికేషన్ ఆధారంగా ఉద్యోగ సమాచారం.'},
    {'cat': 'వ్యవసాయం', 'title': 'రైతులకు ఉపయోగకరమైన సమాచారం', 'text': 'పంటలు, మార్కెట్, వ్యవసాయ పథకాలు మరియు అధికారిక సమాచారం.'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('PRAJA AKSHARAM NEWS',
            style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              child: Image.asset('assets/praja_aksharam_logo.png'),
            ),
            for (final item in ['హోమ్', 'బ్రేకింగ్ న్యూస్', 'జిల్లా వార్తలు', 'గిరిజన వార్తలు', 'విద్య', 'ఉద్యోగాలు', 'వ్యవసాయం', 'వీడియో న్యూస్', 'ఈ-పేపర్', 'మా గురించి', 'సంప్రదించండి'])
              ListTile(
                leading: const Icon(Icons.chevron_right),
                title: Text(item),
                onTap: () => Navigator.pop(context),
              ),
          ],
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Image.asset('assets/praja_aksharam_logo.png', height: 170, fit: BoxFit.contain),
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.red.shade50,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Row(
              children: [
                Icon(Icons.flash_on, color: Colors.red),
                SizedBox(width: 8),
                Expanded(child: Text('BREAKING NEWS • తాజా వార్తలు మీ మొబైల్‌లో')),
              ],
            ),
          ),
          const SizedBox(height: 12),
          for (final n in news)
            Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                contentPadding: const EdgeInsets.all(12),
                title: Text(n['cat']!, style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(n['title']!, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 5),
                      Text(n['text']!),
                    ],
                  ),
                ),
                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              ),
            ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'హోమ్'),
          NavigationDestination(icon: Icon(Icons.play_circle_outline), label: 'వీడియో'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'ఈ-పేపర్'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'ప్రొఫైల్'),
        ],
      ),
    );
  }
}
