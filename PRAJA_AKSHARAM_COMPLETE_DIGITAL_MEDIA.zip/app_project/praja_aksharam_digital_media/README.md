# PRAJA AKSHARAM DIGITAL MEDIA

Includes:
1. mobile_flutter/ - Android/iOS Flutter starter app
2. web/ - responsive public news website
3. admin/ - browser-based admin panel demo
4. backend/ - production API plan
5. mobile_flutter/assets/praja_aksharam_logo.png - supplied logo

## Android APK build
Install Flutter, then:
cd mobile_flutter
flutter pub get
flutter build apk --release

APK output:
build/app/outputs/flutter-apk/release/app-release.apk

## Website
Open web/index.html in a browser or deploy the web folder to a hosting provider.

## Admin
Open admin/index.html. Demo login:
Username: admin
Password: admin123

For a real deployment, replace the demo localStorage authentication with a secure backend and change all credentials.
